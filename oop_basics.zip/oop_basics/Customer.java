package oop_basics;

public class Customer {

	
	
}
