package oop_basics;

public class Vehicle {
	
	private int num_wheels;
	
	public Vehicle(int num_wheels) {
		this.num_wheels = num_wheels;
	}

	public int getNumWheels() {
		return num_wheels;
	}
	
}
