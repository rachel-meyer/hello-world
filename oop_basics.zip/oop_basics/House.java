package oop_basics;

public interface House {
	
	public int getNumRooms();

}
