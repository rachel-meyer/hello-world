package oop_basics.test;

import static org.junit.Assert.*;
import oop_basics.SAccount;
import java.util.*;

import org.junit.*;
import org.junit.runner.*;

public class AccountTest {
	SAccount mum;

	@Before
	public void createAccount() {
		mum = new SAccount("s123","Mercy Brown",1000.0, 600.0);
	}

	@Test
	public void testConstructor() {
		assertEquals(1000.0,mum.getBalance(),0.001);
	}
	@Test
	public void testDeposit1() {
		mum.deposit(10);
		assertEquals(1010,mum.getBalance(),0.001);
		mum.deposit(0);
		assertEquals(1010,mum.getBalance(),0.001);
	}
	
	@Test
	public void TestDeposit2() {
		mum.deposit(-5);
		assertEquals(995,mum.getBalance(),0.001);
	}

	/*
	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testTransfer() {
		fail("Not yet implemented");
	}
	*/

}
