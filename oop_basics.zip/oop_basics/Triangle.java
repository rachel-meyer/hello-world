package oop_basics;

public class Triangle extends Shape {

	double length;
	
	public double computeArea() {
		// TODO Auto-generated method stub
		return length * length;
	}


	@Override
	public void print() {
		// TODO Auto-generated method stub

	}
	
	public static void main(String[] args) {
		
	}

}
